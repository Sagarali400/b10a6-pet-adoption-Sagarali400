const loadCategories = () => {
  fetch("https://openapi.programming-hero.com/api/peddy/categories")
    .then((res) => res.json())
    .then((date) => displayButton(date.categories))
    .catch((error) => console.log(error));
};
const displayButton = (categories) => {
  const buttonContainerDisplay = document.getElementById("button-container");
  for (const buttonDetails of categories) {
    const petButton = document.createElement("div");
    console.log(buttonDetails.category);

    petButton.innerHTML = `<button onclick="loadCategoriesCard(${buttonDetails.id})" class="btn lg:btn-lg btn-outline btn-info"><img class='h-8 lg:h-12' src=${buttonDetails.category_icon}> ${buttonDetails.category}</button>`;

    buttonContainerDisplay.append(petButton);
  }
};
const loadCategoriesCard = (id) => {
 alert(id);
 fetch(`https://openapi.programming-hero.com/api/peddy/pet/${id}`)
 .then((res)=>res.json())
 .then((data)=>console.log(data))
};
loadCategories();

//load cards
const loadCards = () => {
  fetch("https://openapi.programming-hero.com/api/peddy/pets")
    .then((res) => res.json())
    .then((data) => displayCards(data.pets))
    .catch((error) => console.log(error));
};
const displayCards = (petsDetails) => {
  const cardContainer = document.getElementById("card-container");
  cardContainer.innerHTML = "";
  for (const petDetail of petsDetails) {
    const card = document.createElement("div");
    
    card.innerHTML = `
        <div class="card bg-base-100 w-72 mb-3 mt-4 mr-3 shadow-xl">
                    <figure class="mt-3">
                        <img src=${petDetail.image}
                             class="rounded-xl w-64" />
                    </figure>
                    <div class="card-body ">
                        <h2 class="card-title">${petDetail.pet_name}</h2>
                        <p class='flex'><img src="https://img.icons8.com/?size=24&id=tt0XRccN77xf&format=png">Breed:${petDetail.breed}</p>
                        <p class="flex"><img src="https://img.icons8.com/?size=24&id=84997&format=png">Birth:${petDetail.date_of_birth}</p>
                        <p class="flex"><img width="32" height="32" src="https://img.icons8.com/windows/32/mercury.png" alt="mercury"/>Gender: ${petDetail.gender}</p>
                        <p class="flex"><img width="24" height="24" src="https://img.icons8.com/material-two-tone/24/us-dollar--v1.png" alt="us-dollar--v1"/>Price : ${petDetail.price}$</p>
                        <div class="flex justify-between">
                            <button class="btn btn-outline btn-info"><img width="30" height="30" src="https://img.icons8.com/fluency-systems-regular/50/facebook-like--v1.png" alt="facebook-like--v1"/></button>
                            <button class="btn btn-outline btn-info">Adopt</button>
                            <button class="btn btn-outline btn-info">Details</button>
                        </div>
                    </div>
                    <br>
                    
                </div>
        `;
    cardContainer.append(card);
  }
};
loadCards();
